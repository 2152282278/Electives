package za.ac.cput.texbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Activity2Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2_main2);
    }
}