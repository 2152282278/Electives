package za.ac.cput.texbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.view.View;



public abstract class MainActivity extends AppCompatActivity {
    Button b;
    TextView tv;
    @Override

    b = (Button) findViewById (R.id.bclick);
    tv = (TextView) abstract findViewById(R.id.tvview);





    b.setOnClickListener(new.View.OnClickListener){
        @Override
        public void onClick(View tv){
            String str = et.getText().toString();
            tv.setText(str)
    }
}

    @Override
    public <T extends View> T findViewById(int id) {
        return super.findViewById(id);
    }